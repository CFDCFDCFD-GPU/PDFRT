import tkinter as tk
from tkinter import filedialog, messagebox
from PyPDF2 import PdfReader, PdfWriter
import os
import re

class PDFRotateApp:
    def __init__(self, root):
        self.root = root
        self.root.title('PDFRT  PDF页面旋转工具')
        self.pdf_path = ''
        self.output_dir = ''
        self.pdf_label = None
        self.pages_entry = None
        self.angle_var = None
        self.output_label = None
        self.setup_ui()

    def setup_ui(self):
        usage = (
            '                                  PDFRT\n'
            '使用方法                                          Usage：\n'
            '1. 选择PDF文件和输出文件夹。                  1.Select the PDF file and output folder\n'
            '2. 页码输入格式：                                    2.Page number input format:\n'
            '   - 12-23：旋转12到23页（含12和23）            -  12-13: Rotate pages 12 to 23 (including 12 and 23)\n'
            '   - 12/13/15：旋转12、13、15页                    -  12/13/15: Rotate pages 12, 13, and 15\n'
            '   - 18：只旋转第18页                                    -  18: Rotate only page 18\n'
            '3. 选择旋转角度，点击“开始旋转”即可。       3.Select the rotation angle and click “Start Rotation”'

        )
        tk.Label(self.root, text=usage, justify='left', fg='blue').grid(row=0, column=0, columnspan=2, sticky='w', padx=5, pady=5)
        tk.Button(self.root, text='选择PDF文件 Select PDF file', command=self.select_pdf).grid(row=1, column=0, padx=5, pady=5)
        self.pdf_label = tk.Label(self.root, text='未选择')
        self.pdf_label.grid(row=1, column=1, padx=5, pady=5)
        tk.Label(self.root, text='页码输入 Page number input').grid(row=2, column=0, padx=5, pady=5)
        self.pages_entry = tk.Entry(self.root)
        self.pages_entry.grid(row=2, column=1, padx=5, pady=5)
        tk.Label(self.root, text='旋转角度 Rotation angle（deg）').grid(row=3, column=0, padx=5, pady=5)
        self.angle_var = tk.StringVar(value='90')
        tk.OptionMenu(self.root, self.angle_var, '90', '180', '270').grid(row=3, column=1, padx=5, pady=5)
        tk.Button(self.root, text='选择输出文件夹 Select output folder', command=self.select_output_dir).grid(row=4, column=0, padx=5, pady=5)
        self.output_label = tk.Label(self.root, text='未选择')
        self.output_label.grid(row=4, column=1, padx=5, pady=5)
        tk.Button(self.root, text='开始旋转 Start rotating', command=self.rotate_pdf).grid(row=5, column=0, columnspan=2, pady=10)

    def select_pdf(self):
        path = filedialog.askopenfilename(filetypes=[('PDF Files', '*.pdf')])
        if path:
            self.pdf_path = path
            self.pdf_label.config(text=os.path.basename(path))

    def select_output_dir(self):
        dir_path = filedialog.askdirectory()
        if dir_path:
            self.output_dir = dir_path
            self.output_label.config(text=dir_path)

    @staticmethod
    def parse_pages(pages_str, total_pages):
        pages = set()
        for part in re.split(r'[\/，,]', pages_str):
            part = part.strip()
            if not part:
                continue
            if '-' in part:
                try:
                    start, end = map(int, part.split('-'))
                    pages.update(range(start-1, end))
                except:
                    continue
            else:
                try:
                    pages.add(int(part)-1)
                except:
                    continue
        return [p for p in pages if 0 <= p < total_pages]

    def rotate_pdf(self):
        if not self.pdf_path or not self.output_dir:
            messagebox.showerror('错误', '请先选择PDF文件和输出文件夹 Please select the PDF file and output folder first')
            return
        try:
            reader = PdfReader(self.pdf_path)
            writer = PdfWriter()
            total_pages = len(reader.pages)
            pages_str = self.pages_entry.get()
            pages_to_rotate = self.parse_pages(pages_str, total_pages)
            angle = int(self.angle_var.get())
            for i, page in enumerate(reader.pages):
                if i in pages_to_rotate:
                    page.rotate(angle)
                writer.add_page(page)
            output_path = os.path.join(self.output_dir, f'rotated_{os.path.basename(self.pdf_path)}')
            with open(output_path, 'wb') as f:
                writer.write(f)
            messagebox.showinfo('完成 complete', f'旋转完成，输出文件 Rotation completed, output file：{output_path}')
        except Exception as e:
            messagebox.showerror('错误 error', str(e))

if __name__ == '__main__':
    root = tk.Tk()
    app = PDFRotateApp(root)
    root.mainloop()
#本项目由https://github.com/CFDCFDCFD-GPU制作，此项目开源，禁止盈利，转发时请备注原作者